import { Injectable, NotFoundException, BadRequestException, ConflictException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, Like, Between } from 'typeorm';
import { Sweet } from './sweet.entity';
import { CreateSweetDto } from './dto/create-sweet.dto';
import { UpdateSweetDto } from './dto/update-sweet.dto';

@Injectable()
export class SweetsService {
  constructor(
    @InjectRepository(Sweet)
    private readonly sweetRepository: Repository<Sweet>,
  ) {}

  async create(createSweetDto: CreateSweetDto): Promise<Sweet> {
    const existingSweet = await this.sweetRepository.findOne({
      where: { name: createSweetDto.name },
    });

    if (existingSweet) {
      throw new ConflictException('A sweet with this name already exists');
    }

    const sweet = this.sweetRepository.create(createSweetDto);
    return await this.sweetRepository.save(sweet);
  }

  async findAll(): Promise<Sweet[]> {
    return await this.sweetRepository.find({
      order: { createdAt: 'DESC' },
    });
  }

  async findOne(id: string): Promise<Sweet> {
    const sweet = await this.sweetRepository.findOne({ where: { id } });

    if (!sweet) {
      throw new NotFoundException(`Sweet with ID ${id} not found`);
    }

    return sweet;
  }

  async search(name?: string, category?: string, minPrice?: number, maxPrice?: number): Promise<Sweet[]> {
    const queryBuilder = this.sweetRepository.createQueryBuilder('sweet');

    if (name) {
      queryBuilder.andWhere('sweet.name ILIKE :name', { name: `%${name}%` });
    }

    if (category) {
      queryBuilder.andWhere('sweet.category ILIKE :category', { category: `%${category}%` });
    }

    if (minPrice !== undefined) {
      queryBuilder.andWhere('sweet.price >= :minPrice', { minPrice });
    }

    if (maxPrice !== undefined) {
      queryBuilder.andWhere('sweet.price <= :maxPrice', { maxPrice });
    }

    return await queryBuilder.orderBy('sweet.name', 'ASC').getMany();
  }

  async update(id: string, updateSweetDto: UpdateSweetDto): Promise<Sweet> {
    const sweet = await this.findOne(id);

    if (updateSweetDto.name && updateSweetDto.name !== sweet.name) {
      const existingSweet = await this.sweetRepository.findOne({
        where: { name: updateSweetDto.name },
      });

      if (existingSweet) {
        throw new ConflictException('A sweet with this name already exists');
      }
    }

    Object.assign(sweet, updateSweetDto);
    return await this.sweetRepository.save(sweet);
  }

  async remove(id: string): Promise<void> {
    const sweet = await this.findOne(id);
    await this.sweetRepository.remove(sweet);
  }

  async purchase(id: string): Promise<Sweet> {
    const sweet = await this.findOne(id);

    if (sweet.quantity <= 0) {
      throw new BadRequestException('This sweet is out of stock');
    }

    sweet.quantity -= 1;
    return await this.sweetRepository.save(sweet);
  }

  async restock(id: string, amount: number = 1): Promise<Sweet> {
    if (amount <= 0) {
      throw new BadRequestException('Restock amount must be positive');
    }

    const sweet = await this.findOne(id);
    sweet.quantity += amount;
    return await this.sweetRepository.save(sweet);
  }
}