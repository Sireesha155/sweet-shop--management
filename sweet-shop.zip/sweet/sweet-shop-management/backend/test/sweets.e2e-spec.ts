import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import * as request from 'supertest';
import * as bcrypt from 'bcrypt';
import { Repository } from 'typeorm';
import { AppModule } from '../src/app.module';
import { User } from '../src/users/user.entity';
import { UserRole } from '../src/users/user-role.enum';
import { Sweet } from '../src/sweets/sweet.entity';
import { getRepositoryToken } from '@nestjs/typeorm';
import { JwtService } from '@nestjs/jwt';

describe('Sweet Shop E2E Tests', () => {
  let app: INestApplication;
  let adminToken: string;
  let userToken: string;
  let sweetId: string;
  let usersRepository: Repository<User>;
  let sweetsRepository: Repository<Sweet>;
  let jwtService: JwtService;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();

    usersRepository = moduleFixture.get(getRepositoryToken(User));
    sweetsRepository = moduleFixture.get(getRepositoryToken(Sweet));
    jwtService = moduleFixture.get(JwtService);

    // 🔐 Create ADMIN user directly in DB
    const admin = await usersRepository.save({
      email: 'admin@test.com',
      password: await bcrypt.hash('password123', 12),
      role: UserRole.ADMIN,
    });

    adminToken = jwtService.sign({
      sub: admin.id,
      email: admin.email,
      role: admin.role,
    });

    // 👤 Register normal user via API
    const registerRes = await request(app.getHttpServer())
      .post('/api/auth/register')
      .send({
        email: 'user@test.com',
        password: 'password123',
      });

    userToken = registerRes.body.access_token;
  });

  afterAll(async () => {
    // Cleanup: remove test sweets and users
    await sweetsRepository.clear();
    await usersRepository.clear();
    await app.close();
  });

  // ---------------- GET ALL SWEETS ----------------
  describe('/api/sweets (GET)', () => {
    it('should return empty array initially for authenticated user', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/sweets')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBe(0);
    });

    it('should return 401 without token', async () => {
      await request(app.getHttpServer())
        .get('/api/sweets')
        .expect(401);
    });
  });

  // ---------------- CREATE SWEET (ADMIN ONLY) ----------------
  describe('/api/sweets (POST)', () => {
    it('should allow admin to create a sweet', async () => {
      const sweetData = {
        name: 'Ladoo',
        category: 'Traditional',
        price: 50.0, // decimal
        quantity: 10,
      };

      const res = await request(app.getHttpServer())
        .post('/api/sweets')
        .set('Authorization', `Bearer ${adminToken}`)
        .send(sweetData)
        .expect(201);

      sweetId = res.body.id;

      expect(res.body.name).toBe('Ladoo');
      expect(res.body.quantity).toBe(10);
      expect(Number(res.body.price)).toBeCloseTo(50.0);
    });

    it('should forbid non-admin user from creating sweet', async () => {
      await request(app.getHttpServer())
        .post('/api/sweets')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          name: 'Barfi',
          category: 'Traditional',
          price: 40.0,
          quantity: 5,
        })
        .expect(403);
    });
  });

  // ---------------- SEARCH SWEETS ----------------
  describe('/api/sweets/search (GET)', () => {
    it('should return sweets matching name', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/sweets/search?name=Ladoo')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(res.body.length).toBeGreaterThan(0);
      expect(res.body[0].name).toContain('Ladoo');
    });

    it('should filter sweets by minPrice and maxPrice', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/sweets/search?minPrice=40&maxPrice=60')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(res.body[0].price).toBeGreaterThanOrEqual(40);
      expect(res.body[0].price).toBeLessThanOrEqual(60);
    });
  });

  // ---------------- PURCHASE SWEET ----------------
  describe('/api/sweets/:id/purchase (POST)', () => {
    it('should decrease sweet quantity by 1 for normal user', async () => {
      const res = await request(app.getHttpServer())
        .post(`/api/sweets/${sweetId}/purchase`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(201);

      expect(res.body.quantity).toBe(9);
    });

    it('should fail if quantity is zero', async () => {
      // Reduce quantity to 0 first
      await sweetsRepository.update(sweetId, { quantity: 0 });

      await request(app.getHttpServer())
        .post(`/api/sweets/${sweetId}/purchase`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(400);
    });
  });

  // ---------------- RESTOCK SWEET (ADMIN ONLY) ----------------
  describe('/api/sweets/:id/restock (POST)', () => {
    it('should allow admin to restock sweet', async () => {
      const res = await request(app.getHttpServer())
        .post(`/api/sweets/${sweetId}/restock`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ amount: 5 })
        .expect(200);

      expect(res.body.quantity).toBe(5);
    });

    it('should forbid non-admin user from restocking', async () => {
      await request(app.getHttpServer())
        .post(`/api/sweets/${sweetId}/restock`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ amount: 5 })
        .expect(403);
    });
  });

  // ---------------- UPDATE SWEET (ADMIN ONLY) ----------------
  describe('/api/sweets/:id (PUT)', () => {
    it('should allow admin to update sweet', async () => {
      const res = await request(app.getHttpServer())
        .put(`/api/sweets/${sweetId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ price: 55.0 })
        .expect(200);

      expect(Number(res.body.price)).toBeCloseTo(55.0);
    });

    it('should forbid non-admin from updating', async () => {
      await request(app.getHttpServer())
        .put(`/api/sweets/${sweetId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ price: 60.0 })
        .expect(403);
    });
  });

  // ---------------- DELETE SWEET (ADMIN ONLY) ----------------
  describe('/api/sweets/:id (DELETE)', () => {
    it('should allow admin to delete sweet', async () => {
      await request(app.getHttpServer())
        .delete(`/api/sweets/${sweetId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(204);
    });

    it('should forbid non-admin from deleting', async () => {
      const newSweet = await sweetsRepository.save({
        name: 'Jalebi',
        category: 'Traditional',
        price: 30.0,
        quantity: 10,
      });

      await request(app.getHttpServer())
        .delete(`/api/sweets/${newSweet.id}`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(403);
    });
  });
});


