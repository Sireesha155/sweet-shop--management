import { useNavigate } from 'react-router-dom';
import SweetsList from '../components/SweetsList';

interface DashboardProps {
  onLogout: () => void;
  userRole: string;
}

export default function Dashboard({ onLogout, userRole }: DashboardProps) {
  const navigate = useNavigate();
  const isAdmin = userRole === 'admin';

  const handleLogout = () => {
    onLogout();
    navigate('/login');
  };

  return (
    <div className="container">
      <div className="header">
        <h1>🍬 Sweet Shop Dashboard</h1>
        <div style={{ display: 'flex', gap: '1rem' }}>
          {isAdmin && (
            <button
              className="button"
              onClick={() => navigate('/admin')}
              style={{ background: '#4caf50', color: 'white' }}
            >
              Admin Panel
            </button>
          )}
          <button className="button button-danger" onClick={handleLogout}>
            Logout
          </button>
        </div>
      </div>

      <SweetsList isAdmin={false} />
    </div>
  );
}