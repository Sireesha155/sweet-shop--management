import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { SweetsAPI } from '../api/api';
import SweetsList from '../components/SweetsList';
import AdminForm from '../components/AdminForm';

interface AdminPanelProps {
  onLogout: () => void;
}

export default function AdminPanel({ onLogout }: AdminPanelProps) {
  const navigate = useNavigate();
  const [analytics, setAnalytics] = useState({
    totalSweets: 0,
    outOfStock: 0,
    inventoryValue: 0,
  });
  const [refreshKey, setRefreshKey] = useState(0);

  const fetchAnalytics = async () => {
    try {
      const response = await SweetsAPI.getAll();
      const sweets = response.data;

      const totalSweets = sweets.length;
      const outOfStock = sweets.filter((s: any) => s.quantity === 0).length;
      const inventoryValue = sweets.reduce(
        (sum: number, s: any) => sum + s.price * s.quantity,
        0
      );

      setAnalytics({ totalSweets, outOfStock, inventoryValue });
    } catch (err) {
      console.error('Failed to fetch analytics');
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, [refreshKey]);

  const handleLogout = () => {
    onLogout();
    navigate('/login');
  };

  const handleRefresh = () => {
    setRefreshKey((prev) => prev + 1);
  };

  return (
    <div className="container">
      <div className="header">
        <h1>🍬 Admin Panel</h1>
        <div style={{ display: 'flex', gap: '1rem' }}>
          <button
            className="button"
            onClick={() => navigate('/dashboard')}
            style={{ background: '#2196f3', color: 'white' }}
          >
            User View
          </button>
          <button className="button button-danger" onClick={handleLogout}>
            Logout
          </button>
        </div>
      </div>

      <div className="analytics">
        <div className="analytics-card">
          <h3>Total Sweets</h3>
          <div className="value">{analytics.totalSweets}</div>
        </div>
        <div className="analytics-card">
          <h3>Out of Stock</h3>
          <div className="value" style={{ color: '#f44336' }}>
            {analytics.outOfStock}
          </div>
        </div>
        <div className="analytics-card">
          <h3>Inventory Value</h3>
          <div className="value" style={{ color: '#4caf50' }}>
            ₹{analytics.inventoryValue.toFixed(2)}
          </div>
        </div>
      </div>

      <SweetsList isAdmin={true} onRefresh={handleRefresh} />

      <AdminForm onSweetCreated={handleRefresh} />
    </div>
  );
}