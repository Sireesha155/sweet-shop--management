import { usePreferences } from './PreferencesContext';

export const PreferencesPanel = () => {
  const {
    theme,
    fontFamily,
    fontSize,
    language,
    setTheme,
    setFontFamily,
    setFontSize,
    setLanguage,
    toggleFullscreen,
  } = usePreferences();

  return (
    <aside className="preferences-panel">
      <h3>Preferences</h3>

      {/* Theme */}
      <label>
        Theme:
        <select value={theme} onChange={e => setTheme(e.target.value as any)}>
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </label>

      {/* Font family */}
      <label>
        Font:
        <select value={fontFamily} onChange={e => setFontFamily(e.target.value as any)}>
          <option value="default">Default</option>
          <option value="serif">Serif</option>
          <option value="mono">Monospace</option>
        </select>
      </label>

      {/* Font size */}
      <label>
        Font Size:
        <input
          type="range"
          min={14}
          max={20}
          value={fontSize}
          onChange={e => setFontSize(Number(e.target.value))}
        />
      </label>

      {/* Language */}
      <label>
        Language:
        <select value={language} onChange={e => setLanguage(e.target.value as any)}>
          <option value="en">English</option>
          <option value="hi">Hindi</option>
        </select>
      </label>

      {/* Fullscreen */}
      <button onClick={toggleFullscreen}>Toggle Fullscreen</button>
    </aside>
  );
};
