import { createContext, useContext, useEffect, useState } from 'react';

type Theme = 'light' | 'dark';
type FontFamily = 'default' | 'serif' | 'mono';
type Language = 'en' | 'hi';

type Preferences = {
  theme: Theme;
  fontFamily: FontFamily;
  fontSize: number;
  language: Language;
  fullscreen: boolean;
  setTheme: (t: Theme) => void;
  setFontFamily: (f: FontFamily) => void;
  setFontSize: (s: number) => void;
  setLanguage: (l: Language) => void;
  toggleFullscreen: () => void;
};

const PreferencesContext = createContext<Preferences | null>(null);

export const PreferencesProvider = ({ children }: { children: React.ReactNode }) => {
  const [theme, setTheme] = useState<Theme>('light');
  const [fontFamily, setFontFamily] = useState<FontFamily>('default');
  const [fontSize, setFontSize] = useState(16);
  const [language, setLanguage] = useState<Language>('en');
  const [fullscreen, setFullscreen] = useState(false);

  /* Apply preferences */
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.fontSize = `${fontSize}px`;
    document.documentElement.dataset.font = fontFamily;
  }, [theme, fontFamily, fontSize]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setFullscreen(true);
    } else {
      document.exitFullscreen();
      setFullscreen(false);
    }
  };

  return (
    <PreferencesContext.Provider
      value={{
        theme,
        fontFamily,
        fontSize,
        language,
        fullscreen,
        setTheme,
        setFontFamily,
        setFontSize,
        setLanguage,
        toggleFullscreen,
      }}
    >
      {children}
    </PreferencesContext.Provider>
  );
};

export const usePreferences = () => {
  const ctx = useContext(PreferencesContext);
  if (!ctx) throw new Error('Preferences must be used inside provider');
  return ctx;
};
