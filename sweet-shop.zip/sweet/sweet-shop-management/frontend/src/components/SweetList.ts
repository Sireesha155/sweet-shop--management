import { useState, useEffect, useMemo } from 'react';
import { SweetsAPI } from '../api/api';
import SweetCard from './SweetCard';

interface Sweet {
  id: string;
  name: string;
  category: string;
  price: number;
  quantity: number;
}

interface SweetsListProps {
  isAdmin: boolean;
  onRefresh?: () => void;
}

export default function SweetsList({ isAdmin, onRefresh }: SweetsListProps) {
  const [sweets, setSweets] = useState<Sweet[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [searchName, setSearchName] = useState('');
  const [searchCategory, setSearchCategory] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');

  const fetchSweets = async () => {
    try {
      setLoading(true);
      const response = await SweetsAPI.getAll();
      setSweets(response.data);
      setError('');
    } catch (err: any) {
      setError('Failed to load sweets');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSweets();
  }, []);

  const handlePurchase = async (id: string) => {
    try {
      await SweetsAPI.purchase(id);
      await fetchSweets();
      alert('Purchase successful!');
    } catch (err: any) {
      alert(err.response?.data?.message || 'Purchase failed');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this sweet?')) return;

    try {
      await SweetsAPI.delete(id);
      await fetchSweets();
      alert('Sweet deleted successfully');
    } catch (err: any) {
      alert('Delete failed');
    }
  };

  const handleRestock = async (id: string) => {
    const amount = prompt('Enter restock amount:');
    if (!amount || isNaN(Number(amount))) return;

    try {
      await SweetsAPI.restock(id, Number(amount));
      await fetchSweets();
      alert('Restocked successfully');
    } catch (err: any) {
      alert('Restock failed');
    }
  };

  const filteredSweets = useMemo(() => {
    return sweets.filter((sweet) => {
      const matchesName = searchName
        ? sweet.name.toLowerCase().includes(searchName.toLowerCase())
        : true;
      const matchesCategory = searchCategory
        ? sweet.category.toLowerCase().includes(searchCategory.toLowerCase())
        : true;
      const matchesMinPrice = minPrice ? sweet.price >= Number(minPrice) : true;
      const matchesMaxPrice = maxPrice ? sweet.price <= Number(maxPrice) : true;

      return matchesName && matchesCategory && matchesMinPrice && matchesMaxPrice;
    });
  }, [sweets, searchName, searchCategory, minPrice, maxPrice]);

  const categories = useMemo(() => {
    return [...new Set(sweets.map((s) => s.category))];
  }, [sweets]);

  if (loading) return <div>Loading sweets...</div>;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div>
      <div className="filters">
        <input
          type="text"
          placeholder="Search by name..."
          value={searchName}
          onChange={(e) => setSearchName(e.target.value)}
        />
        <select value={searchCategory} onChange={(e) => setSearchCategory(e.target.value)}>
          <option value="">All Categories</option>
          {categories.map((cat) => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>
        <input
          type="number"
          placeholder="Min Price"
          value={minPrice}
          onChange={(e) => setMinPrice(e.target.value)}
        />
        <input
          type="number"
          placeholder="Max Price"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
        />
      </div>

      <div className="sweets-grid">
        {filteredSweets.map((sweet) => (
          <SweetCard
            key={sweet.id}
            sweet={sweet}
            isAdmin={isAdmin}
            onPurchase={handlePurchase}
            onDelete={isAdmin ? handleDelete : undefined}
            onRestock={isAdmin ? handleRestock : undefined}
          />
        ))}
      </div>

      {filteredSweets.length === 0 && (
        <p style={{ textAlign: 'center', marginTop: '2rem' }}>No sweets found</p>
      )}
    </div>
  );
}