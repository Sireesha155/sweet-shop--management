import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token');
      localStorage.removeItem('user_role');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const AuthAPI = {
  register: (email: string, password: string) =>
    api.post('/api/auth/register', { email, password }),
  
  login: (email: string, password: string) =>
    api.post('/api/auth/login', { email, password }),
};

export const SweetsAPI = {
  getAll: () => api.get('/api/sweets'),
  
  getOne: (id: string) => api.get(`/api/sweets/${id}`),
  
  search: (params: { name?: string; category?: string; minPrice?: number; maxPrice?: number }) =>
    api.get('/api/sweets/search', { params }),
  
  create: (data: { name: string; category: string; price: number; quantity: number }) =>
    api.post('/api/sweets', data),
  
  update: (id: string, data: Partial<{ name: string; category: string; price: number; quantity: number }>) =>
    api.put(`/api/sweets/${id}`, data),
  
  delete: (id: string) => api.delete(`/api/sweets/${id}`),
  
  purchase: (id: string) => api.post(`/api/sweets/${id}/purchase`),
  
  restock: (id: string, amount?: number) =>
    api.post(`/api/sweets/${id}/restock`, { amount }),
};