import { memo } from 'react';

interface Sweet {
  id: string;
  name: string;
  category: string;
  price: number;
  quantity: number;
}

interface SweetCardProps {
  sweet: Sweet;
  isAdmin: boolean;
  onPurchase: (id: string) => void;
  onDelete?: (id: string) => void;
  onRestock?: (id: string) => void;
}

function SweetCardComponent({ sweet, isAdmin, onPurchase, onDelete, onRestock }: SweetCardProps) {
  const outOfStock = sweet.quantity === 0;

  return (
    <div className="sweet-card">
      <h3>{sweet.name}</h3>
      <p className="category">{sweet.category}</p>
      <p className="price">₹{Number(sweet.price).toFixed(2)}</p>
      <p className={`stock ${outOfStock ? 'out-of-stock' : 'in-stock'}`}>
        Stock: {sweet.quantity}
      </p>

      <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem', flexWrap: 'wrap' }}>
        <button
          className="button button-primary"
          onClick={() => onPurchase(sweet.id)}
          disabled={outOfStock}
          style={{ flex: 1, opacity: outOfStock ? 0.5 : 1 }}
        >
          {outOfStock ? 'Out of Stock' : 'Purchase'}
        </button>

        {isAdmin && (
          <>
            {onRestock && (
              <button
                className="button"
                onClick={() => onRestock(sweet.id)}
                style={{ backgroundColor: '#4caf50', color: 'white', flex: 1 }}
              >
                Restock
              </button>
            )}
            {onDelete && (
              <button
                className="button button-danger"
                onClick={() => onDelete(sweet.id)}
                style={{ flex: 1 }}
              >
                Delete
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export default memo(SweetCardComponent);