# Sweet Shop Management System
Original code.
