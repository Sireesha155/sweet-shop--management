import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
  ParseFloatPipe,
  ParseIntPipe,
  DefaultValuePipe,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { SweetsService } from './sweets.service';
import { CreateSweetDto } from './dto/create-sweet.dto';
import { UpdateSweetDto } from './dto/update-sweet.dto';
import { AdminGuard } from '../common/guards/admin.guard';

@Controller('api/sweets')
@UseGuards(AuthGuard('jwt'))
export class SweetsController {
  constructor(private readonly sweetsService: SweetsService) {}

  // 🔐 Admin only
  @Post()
  @UseGuards(AdminGuard)
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createSweetDto: CreateSweetDto) {
    return this.sweetsService.create(createSweetDto);
  }

  // 👤 Authenticated users
  @Get()
  async findAll() {
    return this.sweetsService.findAll();
  }

  // 🔍 Search with correct numeric parsing
  @Get('search')
  async search(
    @Query('name') name?: string,
    @Query('category') category?: string,
    @Query('minPrice', new DefaultValuePipe(undefined), ParseFloatPipe)
    minPrice?: number,
    @Query('maxPrice', new DefaultValuePipe(undefined), ParseFloatPipe)
    maxPrice?: number,
  ) {
    return this.sweetsService.search(name, category, minPrice, maxPrice);
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.sweetsService.findOne(id);
  }

  // 🔐 Admin only
  @Put(':id')
  @UseGuards(AdminGuard)
  async update(
    @Param('id') id: string,
    @Body() updateSweetDto: UpdateSweetDto,
  ) {
    return this.sweetsService.update(id, updateSweetDto);
  }

  // 🔐 Admin only
  @Delete(':id')
  @UseGuards(AdminGuard)
  @HttpCode(HttpStatus.NO_CONTENT)
  async remove(@Param('id') id: string) {
    await this.sweetsService.remove(id);
  }

  // 👤 Purchase (authenticated user)
  @Post(':id/purchase')
  async purchase(@Param('id') id: string) {
    return this.sweetsService.purchase(id);
  }

  // 🔐 Admin only — safe integer handling
  @Post(':id/restock')
  @UseGuards(AdminGuard)
  async restock(
    @Param('id') id: string,
    @Body(
      'amount',
      new DefaultValuePipe(1),
      ParseIntPipe,
    )
    amount: number,
  ) {
    return this.sweetsService.restock(id, amount);
  }
}


