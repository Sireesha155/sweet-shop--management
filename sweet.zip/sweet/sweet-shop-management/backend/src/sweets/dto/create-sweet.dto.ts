import { IsString, IsNotEmpty, IsNumber, Min, MaxLength } from 'class-validator';

export class CreateSweetDto {
  @IsString()
  @IsNotEmpty({ message: 'Sweet name is required' })
  @MaxLength(255, { message: 'Name is too long' })
  name: string;

  @IsString()
  @IsNotEmpty({ message: 'Category is required' })
  @MaxLength(100, { message: 'Category name is too long' })
  category: string;

  @IsNumber({}, { message: 'Price must be a valid number' })
  @Min(0, { message: 'Price cannot be negative' })
  price: number;

  @IsNumber({}, { message: 'Quantity must be a valid number' })
  @Min(0, { message: 'Quantity cannot be negative' })
  quantity: number;
}

