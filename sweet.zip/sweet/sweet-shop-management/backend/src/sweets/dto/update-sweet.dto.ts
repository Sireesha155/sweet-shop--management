import { IsString, IsNumber, Min, MaxLength, IsOptional } from 'class-validator';

export class UpdateSweetDto {
  @IsOptional()
  @IsString()
  @MaxLength(255, { message: 'Name is too long' })
  name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100, { message: 'Category name is too long' })
  category?: string;

  @IsOptional()
  @IsNumber({}, { message: 'Price must be a valid number' })
  @Min(0, { message: 'Price cannot be negative' })
  price?: number;

  @IsOptional()
  @IsNumber({}, { message: 'Quantity must be a valid number' })
  @Min(0, { message: 'Quantity cannot be negative' })
  quantity?: number;
}

